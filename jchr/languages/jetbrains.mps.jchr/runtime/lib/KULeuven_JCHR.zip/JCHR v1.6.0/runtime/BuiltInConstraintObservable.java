package runtime;

public interface BuiltInConstraintObservable {
    public void addBuiltInConstraintObserver(Constraint constraint);

}