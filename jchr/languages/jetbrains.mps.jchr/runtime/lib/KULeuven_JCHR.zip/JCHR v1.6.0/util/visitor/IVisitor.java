package util.visitor;

/**
 * A simple indicator interface. 
 * Still useful I think to track where the visitor pattern is used.
 * 
 * @author Peter Van Weert
 */
public interface IVisitor {
    // indicator interface
}
