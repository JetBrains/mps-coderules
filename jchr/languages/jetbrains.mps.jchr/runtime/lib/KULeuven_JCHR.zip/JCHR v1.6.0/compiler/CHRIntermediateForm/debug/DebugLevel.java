package compiler.CHRIntermediateForm.debug;

public enum DebugLevel { OFF, DEFAULT, FULL }
