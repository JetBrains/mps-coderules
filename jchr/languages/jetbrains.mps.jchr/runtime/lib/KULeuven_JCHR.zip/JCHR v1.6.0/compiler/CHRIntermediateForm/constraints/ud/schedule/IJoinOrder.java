package compiler.CHRIntermediateForm.constraints.ud.schedule;

public interface IJoinOrder 
    extends Iterable<IJoinOrderElement>, IJoinOrderVisitable {
    // no new methods
}