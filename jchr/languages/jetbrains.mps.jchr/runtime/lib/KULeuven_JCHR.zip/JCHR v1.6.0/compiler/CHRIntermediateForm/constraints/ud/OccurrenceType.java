package compiler.CHRIntermediateForm.constraints.ud;

public enum OccurrenceType {
    KEPT,
    REMOVED,
    NEGATIVE;
}