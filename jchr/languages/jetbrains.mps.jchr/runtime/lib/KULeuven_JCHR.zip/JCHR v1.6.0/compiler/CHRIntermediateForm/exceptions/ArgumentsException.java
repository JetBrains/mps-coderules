package compiler.CHRIntermediateForm.exceptions;

public class ArgumentsException extends Exception {
    private static final long serialVersionUID = 1L;

    public ArgumentsException(String message) {
        super(message);
    }
}
