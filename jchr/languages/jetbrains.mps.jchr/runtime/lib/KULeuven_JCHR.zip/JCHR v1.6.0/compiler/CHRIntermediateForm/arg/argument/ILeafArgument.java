package compiler.CHRIntermediateForm.arg.argument;

public interface ILeafArgument extends IArgument {
    // No extra methods
}