package compiler.CHRIntermediateForm.modifiers;

public interface IModified {
    public int getModifiers();
}
