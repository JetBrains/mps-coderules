package compiler.CHRIntermediateForm;

public enum Cost { FREE, VERY_CHEAP, MODERATE, EXPENSIVE }