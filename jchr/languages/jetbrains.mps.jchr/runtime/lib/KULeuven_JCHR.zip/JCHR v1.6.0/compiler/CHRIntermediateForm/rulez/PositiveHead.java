package compiler.CHRIntermediateForm.rulez;

public abstract class PositiveHead extends Head {

    // no extra members anymore for now...
}
