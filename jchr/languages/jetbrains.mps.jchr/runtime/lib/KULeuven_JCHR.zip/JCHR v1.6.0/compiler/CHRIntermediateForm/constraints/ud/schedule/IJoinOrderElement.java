package compiler.CHRIntermediateForm.constraints.ud.schedule;

public interface IJoinOrderElement extends IJoinOrderVisitable {

    /* indicator interface */
}
