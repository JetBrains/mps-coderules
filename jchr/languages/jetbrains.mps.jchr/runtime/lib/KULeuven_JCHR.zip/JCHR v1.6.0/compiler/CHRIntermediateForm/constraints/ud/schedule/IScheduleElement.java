package compiler.CHRIntermediateForm.constraints.ud.schedule;

public interface IScheduleElement extends IScheduleVisitable {

    /* indicator interface */
}
